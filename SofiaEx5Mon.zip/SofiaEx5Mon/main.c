#include "lista.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SAIR 0
#define SAQUE 1
#define DEPOSITO 2
#define TRANSFERENCIA 3
#define CADASTRAR 4
#define RELATORIO 5
#define EXTRATO 6

tLista* executa_acao(tLista*(*funcao)(tLista*, int, int, double), FILE *a, tLista *l, int nConta1, int nConta2, double valor){
  char confirmacao='s';
  while (confirmacao=='s'|| confirmacao=='n'){
  fscanf(a, "%c%*c", &confirmacao);
  if (confirmacao=='s'){
    return funcao(l, nConta1, nConta2, valor);
  }
  return l;
  }
}

int main(int argc, char * argv[]) {
  tLista *lista = Lista_inicializa();
  int cpf = 0, acao = 10, numConta, numConta2, qtdMov;
  double valor = 0.000;
  char nome[50], temp[10];

  FILE * arqEntrada = fopen(argv[1], "r");

  if (arqEntrada==NULL){
    printf("Arquivo '%s' não encontrado!\n", argv[1]);
    return 1;
  }

  while (1) {

    fscanf(arqEntrada,"%d%*c", &acao);
    if (acao == SAIR) {
      break;
    }
    else if (acao == SAQUE) {
      fscanf(arqEntrada, "%d %lf%*c", &numConta, &valor);
      lista = executa_acao(Lista_saque, arqEntrada, lista, numConta, 0, valor );
      //Lista_saque(lista, numConta, 0, valor);
    }

    else if (acao == DEPOSITO) {
      fscanf(arqEntrada, "%d %lf%*c", &numConta, &valor);
      lista = executa_acao(Lista_deposito, arqEntrada, lista, numConta, 0, valor );
    }

    else if (acao == TRANSFERENCIA) {
      fscanf(arqEntrada, "%d %d %lf%*c", &numConta, &numConta2, &valor);
      lista = executa_acao(Lista_transferencia, arqEntrada, lista, numConta, numConta2, valor );
    
    }

    else if (acao == CADASTRAR) {
      int numConta;
      fscanf(arqEntrada, "%30s %d %d%*c", nome, &cpf, &numConta);
      lista = Lista_add_conta(lista, numConta, nome, cpf);
    }

    else if (acao == RELATORIO) {
      char endSaida[20]="saida/relatorio.txt";
      FILE * arqSaida = fopen(endSaida, "w");

      if (arqSaida==NULL){
        printf("Arquivo '%s' não encontrado!\n", endSaida);
        return 1;
      }

      fprintf(arqSaida,"===| Imprimindo Relatorio |===\n");
      Lista_imprime(lista, arqSaida);
    }

    else if (acao == EXTRATO) {
      fscanf(arqEntrada, "%s %d%*c", temp, &qtdMov);
      char endSaida[20]="saida/";
      strcat(endSaida, temp);
      strcat(endSaida, ".txt");
      FILE * arqSaida = fopen(endSaida, "w");

      if (arqSaida==NULL){
        printf("Arquivo '%s' não encontrado!\n", endSaida);
        return 1;
      }

      fprintf(arqSaida,"===| Imprimindo Extrato |===\n");
      int x=atoi(temp);
      Conta_imprime(Lista_get_user(lista, x), arqSaida);
      fprintf(arqSaida,"Ultimas %d transações\n", qtdMov);
      Conta_imprime_transacoes(arqSaida, Lista_get_user(lista, x), qtdMov);
    }
  }
 Lista_destroi(lista);
  return 0;
}
