#ifndef LISTA_H
#define LISTA_H

#include "conta.h"
#include "usuario.h"
#include <stdio.h>

typedef struct lista tLista;

tLista *Lista_inicializa();

tLista *Lista_add_conta(tLista *l, int numConta, char *nome, int cpf);

tConta * Lista_get_user(tLista *l, int num);

void Lista_imprime(tLista *l, FILE *);

tLista * Lista_saque(tLista *l, int numConta, int lixo, double valor);

tLista * Lista_deposito(tLista *l, int numConta, int lixo, double valor);

tLista * Lista_transferencia(tLista *l, int numConta, int numConta2, double valor);

void Lista_destroi(tLista *l);

#endif