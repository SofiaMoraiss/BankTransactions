
#include "conta.h"
// #include "usuario.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct conta
{
  tUsuario *user;
  int numero, qtd_transacoes, qtd_t_alocadas;
  double saldo;
  double *vetTransacoes;
};

tConta *Conta_inicializa(int num, char *nome, int cpf)
{
  tUsuario *user = Usuario_inicializa(nome, cpf);
  tConta *conta = calloc(1, sizeof(tConta));
  conta->vetTransacoes = calloc(1, sizeof(double));
  
  conta->user = user;
  conta->qtd_transacoes=0;
  conta->qtd_t_alocadas=0;
  conta->numero = num;
  conta->saldo = 0;

  return conta;
}

static void Conta_add_transacao(tConta * c, double valor){
  if (c->qtd_transacoes>=c->qtd_t_alocadas){
    c->vetTransacoes=realloc(c->vetTransacoes, (c->qtd_transacoes+1)*sizeof(double));
  }
  c->vetTransacoes[c->qtd_transacoes]=valor;
  c->qtd_transacoes++;
}

double Conta_get_saldo(tConta*c){
  return c->saldo;
}

int Conta_get_numero(tConta*c){
  return c->numero;
}

tUsuario* Conta_get_user(tConta*c){
  return c->user;
}

tConta *Conta_saque(tConta *c, double valor)
{
  if (c->saldo - valor < 0)
  {
    printf("Saldo insuficiente!\n\n");
    return c;
  }
  c->saldo -= valor;
  valor*=-1;
  Conta_add_transacao(c, valor);
  //printf("\nSaque realizado na conta %d com valor de %.2f\nSaldo atual: %.2lf\n\n", c->numero,  valor, c->saldo);
  return c;
}

tConta *Conta_deposito(tConta *c, double valor)
{
  c->saldo += valor;
  Conta_add_transacao(c, valor);
  //printf("\nDeposito realizado na conta %d com valor de %.2f\nSaldo atual: %.2lf\n\n", c->numero,  valor, c->saldo);
  return c;
}

void Conta_destroi(tConta *c)
{
  Usuario_destroi(c->user);
  free(c);
}

void Conta_imprime(tConta *c, FILE * a)
{
  fprintf(a, "Conta: %d\nSaldo: R$ %.2f\n", c->numero, c->saldo);
  Usuario_imprime(c->user, a);
}

void Conta_imprime_transacoes(FILE *a, tConta *c, int qtd)
{
  int temp=c->qtd_transacoes;
  while (qtd>0){
    fprintf(a, "%.2lf\n", c->vetTransacoes[temp-1]);
    temp--;
    qtd--;
  }
}
