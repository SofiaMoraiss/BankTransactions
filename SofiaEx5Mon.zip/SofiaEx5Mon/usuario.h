#ifndef USUARIO_H
#define USUARIO_H

#include <stdio.h>

typedef struct usuario tUsuario;

tUsuario * Usuario_inicializa(char* nome, int cpf);
void Usuario_imprime(tUsuario *u, FILE *);
void Usuario_destroi(tUsuario *user);
//int usuario_aprovado(tusuario);
//tusuario usuario_le(tUsuario);

#endif

