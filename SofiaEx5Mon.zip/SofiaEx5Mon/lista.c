#include "lista.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct lista{
  tConta **vetContas;
  int qtd_lidas;
  int qtd_alocadas;
};

tLista *Lista_inicializa() {
  tLista *l = calloc(1, sizeof(tLista));
  l->vetContas = calloc(1, sizeof(tConta *));
  l->qtd_alocadas = 1;
  l->qtd_lidas = 0;
  return l;
}

tLista *Lista_add_conta(tLista *l, int numConta, char *nome, int cpf) {
  if (numConta >= l->qtd_alocadas) {
    l->vetContas =
        realloc(l->vetContas, (numConta+1)* sizeof(tConta *));
    l->qtd_alocadas =numConta+1;
  }
    l->qtd_lidas++;
    l->vetContas[numConta]=Conta_inicializa(numConta, nome, cpf);

  return l;
}

tConta * Lista_get_user(tLista *l, int num){
  return l->vetContas[num];
}

void Lista_imprime(tLista *l, FILE * a) {
  for(int i=0; i<l->qtd_alocadas; i++){
    if (l->vetContas[i]!=NULL){
      Conta_imprime(l->vetContas[i], a);
    }
  }
}

tLista * Lista_saque(tLista *l, int numConta, int lixo, double valor) {
  l->vetContas[numConta]=Conta_saque(l->vetContas[numConta], valor);
  return l;
}

tLista * Lista_deposito(tLista *l, int numConta, int lixo, double valor) {
  l->vetContas[numConta]=Conta_deposito(l->vetContas[numConta], valor);
  return l;
}

tLista * Lista_transferencia(tLista *l, int numConta, int numConta2, double valor) {
  if (Conta_get_saldo(l->vetContas[numConta])<valor ){
    return l;
  }
  if (valor<= 0){
    return l;
  }
  l->vetContas[numConta]=Conta_saque(l->vetContas[numConta], valor);
  l->vetContas[numConta2]=Conta_deposito(l->vetContas[numConta2], valor);
  return l;
}

void Lista_destroi(tLista *l) {
  for (int i = 0; i < l->qtd_alocadas; i++) {
    if(l->vetContas[i]!=NULL){
        Conta_destroi(l->vetContas[i]);
    }
  }
  free(l->vetContas);
  free(l);
}