
#include "usuario.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct usuario {
  char nome[50];
  int cpf;
};

tUsuario *Usuario_inicializa(char *nome, int cpf) {
  tUsuario *user = calloc(1, sizeof(tUsuario));
  strcpy(user->nome, nome);
  user->cpf = cpf;

  return user;
}
void Usuario_imprime(tUsuario *u, FILE * a){
  fprintf(a, "Nome: %s\nCPF: %d\n\n", u->nome, u->cpf);
}

void Usuario_destroi(tUsuario *user) { free(user); }