#ifndef CONTA_H
#define CONTA_H

#include "usuario.h"
#include <stdio.h>

typedef struct conta tConta;

tConta *Conta_inicializa(int num, char *nome, int cpf);
double Conta_get_saldo(tConta*c);
int Conta_get_numero(tConta*c);
tUsuario * Conta_get_user(tConta*c);
tConta * Conta_saque(tConta * c, double valor);
tConta *Conta_deposito(tConta *c, double valor);
void Conta_imprime(tConta *c, FILE *);
void Conta_imprime_transacoes(FILE *a, tConta *c, int qtd);
void Conta_destroi(tConta *c);

#endif
